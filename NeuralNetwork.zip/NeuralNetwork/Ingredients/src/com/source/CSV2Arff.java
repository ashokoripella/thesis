package com.source;

import weka.core.Instances;
import weka.core.converters.ArffSaver;
import weka.core.converters.ArffLoader;
import weka.core.converters.CSVLoader;
import weka.core.converters.CSVSaver;
import java.io.*;

public class CSV2Arff {
  
  
    public static String CSV2Arffc(String fn) throws Exception
    {
    // load CSV
    CSVLoader loader = new CSVLoader();
    loader.setSource(new File(fn));
    Instances data = loader.getDataSet();//get instances object
System.out.println("CSV2Arff=>"+fn);
    // save ARFF
    //ArffSaver saver = new ArffSaver();
    //saver.setInstances(data);//set the dataset we want to convert
    //and save as ARFF
    File f=new File(fn);
	String ff=f.getName();
	
	String driveLetter = ff.split("\\.")[0];
	String fn1="arff_"+driveLetter+".arff";
    String fp="E:/input/"+fn1;
   // saver.setFile(new File(fp));
    //saver.writeBatch();
    BufferedWriter writer = new BufferedWriter(new FileWriter(fp));
    writer.write(data.toString());
    writer.flush();
    writer.close();
    return fp;
    }
    public String Arff2CSVc(String fn) throws Exception
    {

    	//load ARFF
    ArffLoader loader = new ArffLoader();
    loader.setSource(new File(fn));
    Instances data = loader.getDataSet();//get instances object
    // save ARFF
    CSVSaver saver = new CSVSaver();
   saver.setInstances(data);//set the dataset we want to convert
    //and save as ARFF
    File f=new File(fn);
	String ff=f.getName();
	String driveLetter = ff.split("\\.")[0];
	String fn1="csv_"+driveLetter+".csv";
    String fp="E:/input/"+fn1;
    saver.setFile(new File(fp));
    saver.writeBatch();
    /*BufferedWriter writer = new BufferedWriter(new FileWriter(fp));
    writer.write(data.toString());
    writer.flush();
    writer.close();*/
    return fp;
    }
    public static void main(String[] args) throws Exception {
    	CSV2Arff conv=new CSV2Arff();
    	System.out.println("CSV to Arff Conversion Started....");
    	String fp=conv.CSV2Arffc("C:\\Users\\logid0007\\Desktop\\DSet\\FullLabelledDataset.csv");
    	System.out.println("CSV to Arff Conversion Done....");
    	/*System.out.println("Arff to CSV Conversion Started....");
    	conv.Arff2CSVc(fp);
    	System.out.println("Arff to CSV Conversion Done....");*/
    }
} 
