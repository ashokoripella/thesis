package com.source;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import weka.classifiers.Classifier;
import weka.classifiers.Evaluation;
import weka.classifiers.functions.MultilayerPerceptron;
import weka.core.Instances;


public class NeuralNetwork {
	public static BufferedReader readDataFile(String filename) {
		BufferedReader inputReader = null;
 
		try {
			inputReader = new BufferedReader(new FileReader(filename));
		} catch (FileNotFoundException ex) {
			System.err.println("File not found: " + filename);
		}
 
		return inputReader;
	}
	public static String NeuralTest(String fn,double percentage) throws Exception {
		String fp=CSV2Arff.CSV2Arffc(fn);
		BufferedReader datafile = readDataFile(fp);
		Instances data = new Instances(datafile);
		data.setClassIndex(data.numAttributes() - 1);
		
		Classifier classifier = new MultilayerPerceptron();
		
		classifier.buildClassifier(data);
		
		
		//split to 70:30 learn and test set
		double percent = percentage;
		int trainSize = (int) Math.round(data.numInstances() * percent / 100);
		int testSize = data.numInstances() - trainSize;
		Instances train = new Instances(data, 0, trainSize);
		Instances test = new Instances(data, trainSize, testSize);
		
		//do eval
		Evaluation eval = new Evaluation(train); //trainset
		eval.evaluateModel(classifier, test); //testset
		
		return "<pre>"+eval.toClassDetailsString()+"</pre>~<pre>"+eval.toMatrixString()+"</pre>~<pre>"+eval.toSummaryString()+"</pre>";
	}
	public static void main(String[] args) throws Exception 
	{
			
		System.out.println(NeuralTest("E:\\\\Clients\\\\6ashok\\\\ashok\\\\FinalSet.csv", 70));
	}
}