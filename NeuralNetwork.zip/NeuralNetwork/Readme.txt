e:/input/
E:\Clients\6ashok\ashok